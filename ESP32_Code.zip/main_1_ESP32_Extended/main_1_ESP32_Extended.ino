#include <Arduino.h>
#include <WiFi.h>

#include "Config.h"
#include "TelemetryData.h"
#include "STM32_Comm.h"
#include "Blynk_Comm.h"
#include "Telegram_Comm.h"

CapTelemetry telem;

unsigned long lastBlynkUpdate = 0;
unsigned long lastWifiReconnectTry = 0;

void connectWiFi() {
  WiFi.mode(WIFI_STA);
  WiFi.begin(ssid, password);

  Serial.print("WiFi connecting");
  unsigned long start = millis();
  while (WiFi.status() != WL_CONNECTED && (millis() - start) < 10000UL) {
    delay(250);
    Serial.print(".");
  }
  Serial.println();

  if (WiFi.status() == WL_CONNECTED) {
    Serial.print("WiFi connected: ");
    Serial.println(WiFi.localIP());
  } else {
    Serial.println("WiFi connection failed. It will retry in loop().");
  }
}

void maintainWiFiAndBlynk() {
  if (WiFi.status() != WL_CONNECTED) {
    if (millis() - lastWifiReconnectTry > WIFI_RECONNECT_INTERVAL_MS) {
      lastWifiReconnectTry = millis();
      Serial.println("WiFi reconnecting...");
      WiFi.disconnect();
      WiFi.begin(ssid, password);
    }
    return;
  }

  if (!Blynk.connected()) {
    Blynk.connect(1000);
  }
}

void setup() {
  Serial.begin(115200);
  delay(300);

  initSTM32Serial();
  connectWiFi();
  initBlynk();
  initTelegram();

  Serial.println("ESP32 Extended Inverter Monitor Ready");
}

void loop() {
  readSTM32Data();

  maintainWiFiAndBlynk();

  if (WiFi.status() == WL_CONNECTED && Blynk.connected()) {
    Blynk.run();

    if (millis() - lastBlynkUpdate > BLYNK_UPDATE_INTERVAL_MS) {
      updateBlynk();
      lastBlynkUpdate = millis();
    }
  }

  // Telegram 처리 직전에 최신 STM32 데이터 한 번 더 반영
  readSTM32Data();

  runTelegram();
  checkAndSendTelemetryEvent();
}
