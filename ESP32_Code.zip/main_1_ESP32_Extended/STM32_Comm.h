#pragma once
#include <Arduino.h>
#include "Config.h"
#include "TelemetryData.h"

void initSTM32Serial() {
  Serial2.begin(STM32_BAUDRATE, SERIAL_8N1, STM32_RXD2, STM32_TXD2);
  Serial2.setTimeout(20);
}

static float parseFloatSafe(const String& s, float fallback = 0.0f) {
  String v = s;
  v.trim();
  if (v.length() == 0) return fallback;
  return v.toFloat();
}

static uint8_t parseU8Safe(const String& s, uint8_t fallback = 0) {
  String v = s;
  v.trim();
  if (v.length() == 0) return fallback;
  long n = v.toInt();
  if (n < 0) n = 0;
  if (n > 255) n = 255;
  return (uint8_t)n;
}

static uint32_t parseU32Safe(const String& s, uint32_t fallback = 0) {
  String v = s;
  v.trim();
  if (v.length() == 0) return fallback;
  long n = v.toInt();
  if (n < 0) return fallback;
  return (uint32_t)n;
}

static void applyTelemetryKeyValue(const String& key, const String& value) {
  if (key == "t") telem.time_s = parseU32Safe(value, telem.time_s);
  else if (key == "st") telem.final_state_num = parseU8Safe(value, telem.final_state_num);
  else if (key == "label") telem.state_label = value;
  else if (key == "fault") telem.fault_type = value;
  else if (key == "trip") telem.trip_reason = value;
  else if (key == "relay") telem.relay_state = parseU8Safe(value, telem.relay_state);
  else if (key == "relaycmd") telem.relay_cmd = parseU8Safe(value, telem.relay_cmd);
  else if (key == "tripf") telem.trip_flag = parseU8Safe(value, telem.trip_flag);
  else if (key == "fan") telem.fan_state = parseU8Safe(value, telem.fan_state);
  else if (key == "Vdc") telem.vdc_v = parseFloatSafe(value, telem.vdc_v);
  else if (key == "Idc") telem.idc_a = parseFloatSafe(value, telem.idc_a);
  else if (key == "Pdc") telem.pdc_w = parseFloatSafe(value, telem.pdc_w);
  else if (key == "Vout") telem.vout_rms = parseFloatSafe(value, telem.vout_rms);
  else if (key == "Iout") telem.iout_rms = parseFloatSafe(value, telem.iout_rms);
  else if (key == "Pout") telem.pout_w = parseFloatSafe(value, telem.pout_w);
  else if (key == "PF") telem.pf = parseFloatSafe(value, telem.pf);
  else if (key == "T") telem.temp_c = parseFloatSafe(value, telem.temp_c);
  else if (key == "Ploss") telem.ploss_w = parseFloatSafe(value, telem.ploss_w);
  else if (key == "Eff") telem.efficiency = parseFloatSafe(value, telem.efficiency);
  else if (key == "dTdt") telem.dtdt_c_per_min = parseFloatSafe(value, telem.dtdt_c_per_min);
  else if (key == "Score") telem.cascade_protect_score = parseFloatSafe(value, telem.cascade_protect_score);
  else if (key == "Re") telem.electrical_score = parseFloatSafe(value, telem.electrical_score);
  else if (key == "Rl") telem.loss_score = parseFloatSafe(value, telem.loss_score);
  else if (key == "Rt") telem.thermal_score = parseFloatSafe(value, telem.thermal_score);
  else if (key == "Cmax") telem.cascade_max_score = parseFloatSafe(value, telem.cascade_max_score);
  else if (key == "Cw") telem.cascade_weighted_score = parseFloatSafe(value, telem.cascade_weighted_score);
  else if (key == "Ch") telem.cascade_hybrid_score = parseFloatSafe(value, telem.cascade_hybrid_score);
  else if (key == "Fstate") telem.final_anfis_state = parseU8Safe(value, telem.final_anfis_state);
  else if (key == "Fscore") telem.final_anfis_score = parseFloatSafe(value, telem.final_anfis_score);
  else if (key == "Anfis") telem.anfis_valid = parseU8Safe(value, telem.anfis_valid);
  else if (key == "Rule") telem.rule_state_num = parseU8Safe(value, telem.rule_state_num);
  else if (key == "Load") telem.load_id = value;
  else if (key == "Conf") telem.load_confidence = parseU8Safe(value, telem.load_confidence);
  else if (key == "Trans") telem.transient_flag = parseU8Safe(value, telem.transient_flag);
  else if (key == "ACok") telem.ac_ok = parseU8Safe(value, telem.ac_ok);
  else if (key == "DCok") telem.dc_ok = parseU8Safe(value, telem.dc_ok);
  else if (key == "Pair") telem.pzem_pair_ok = parseU8Safe(value, telem.pzem_pair_ok);
  else if (key == "Retry") telem.auto_retry_count = parseU8Safe(value, telem.auto_retry_count);
  else if (key == "Rstate") telem.retry_state = value;
  else if (key == "Latched") telem.latched_trip = parseU8Safe(value, telem.latched_trip);
}

static bool parseCAPTelemetry(String line) {
  line.trim();
  if (!line.startsWith("CAP,")) return false;

  int start = 4; // after "CAP,"
  while (start < line.length()) {
    int comma = line.indexOf(',', start);
    String token = (comma >= 0) ? line.substring(start, comma) : line.substring(start);
    token.trim();

    int eq = token.indexOf('=');
    if (eq > 0) {
      String key = token.substring(0, eq);
      String value = token.substring(eq + 1);
      key.trim();
      value.trim();
      applyTelemetryKeyValue(key, value);
    }

    if (comma < 0) break;
    start = comma + 1;
  }

  telem.valid = true;
  telem.rxCount++;
  telem.lastRxMs = millis();
  return true;
}

void readSTM32Data() {
  while (Serial2.available()) {
    String line = Serial2.readStringUntil('\n');
    line.trim();
    if (line.length() == 0) continue;

    if (parseCAPTelemetry(line)) {
      Serial.println("STM32 CAP OK: st=" + String(telem.final_state_num) +
                     ", fault=" + telem.fault_type +
                     ", Vdc=" + String(telem.vdc_v, 2) +
                     ", Vout=" + String(telem.vout_rms, 1) +
                     ", T=" + String(telem.temp_c, 1));
    } else {
      // CSV/Hercules 로그나 디버그 문자열이 같은 UART로 들어오더라도 무시합니다.
      Serial.println("STM32 ignored: " + line);
    }
  }
}
