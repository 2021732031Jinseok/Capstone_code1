#pragma once

#include "Config.h"
#include "TelemetryData.h"
#include <BlynkSimpleEsp32.h>

void initBlynk() {
  Blynk.config(BLYNK_AUTH_TOKEN);
  Blynk.connect(5000);
}

void updateBlynk() {
  bool stale = telemIsStale(TELEMETRY_STALE_MS);

  Blynk.virtualWrite(V0, telem.final_state_num);
  Blynk.virtualWrite(V1, stale ? "STM32 통신 없음" : telem.state_label);
  Blynk.virtualWrite(V2, telem.fault_type);
  Blynk.virtualWrite(V3, telem.trip_reason);
  Blynk.virtualWrite(V4, relayText());
  Blynk.virtualWrite(V5, telem.trip_flag);

  Blynk.virtualWrite(V6, telem.vdc_v);
  Blynk.virtualWrite(V7, telem.idc_a);
  Blynk.virtualWrite(V8, telem.pdc_w);
  Blynk.virtualWrite(V9, telem.vout_rms);
  Blynk.virtualWrite(V10, telem.iout_rms);
  Blynk.virtualWrite(V11, telem.pout_w);
  Blynk.virtualWrite(V12, telem.pf);
  Blynk.virtualWrite(V13, telem.temp_c);

  Blynk.virtualWrite(V14, telem.ploss_w);
  Blynk.virtualWrite(V15, telem.efficiency * 100.0f);
  Blynk.virtualWrite(V16, telem.dtdt_c_per_min);

  Blynk.virtualWrite(V17, telem.cascade_protect_score);
  Blynk.virtualWrite(V18, telem.electrical_score);
  Blynk.virtualWrite(V19, telem.loss_score);
  Blynk.virtualWrite(V20, telem.thermal_score);
  Blynk.virtualWrite(V21, telem.final_anfis_score);

  Blynk.virtualWrite(V22, telem.load_id);
  Blynk.virtualWrite(V23, telem.load_confidence);
  Blynk.virtualWrite(V24, telem.transient_flag);

  Blynk.virtualWrite(V25, telem.ac_ok);
  Blynk.virtualWrite(V26, telem.dc_ok);
  Blynk.virtualWrite(V27, telem.pzem_pair_ok);
  Blynk.virtualWrite(V28, stale ? 0 : 1);

  Blynk.virtualWrite(V29, telem.auto_retry_count);
  Blynk.virtualWrite(V30, telem.retry_state);
  Blynk.virtualWrite(V31, telem.latched_trip);
  Blynk.virtualWrite(V32, telem.rxCount);
}
