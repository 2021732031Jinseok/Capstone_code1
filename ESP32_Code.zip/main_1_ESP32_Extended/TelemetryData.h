#pragma once
#include <Arduino.h>

struct CapTelemetry {
  bool valid = false;
  uint32_t rxCount = 0;
  unsigned long lastRxMs = 0;

  uint32_t time_s = 0;
  uint8_t final_state_num = 0;
  uint8_t rule_state_num = 0;
  String state_label = "S0_NORMAL";
  String fault_type = "NORMAL";
  String trip_reason = "NORMAL";

  uint8_t relay_state = 0;
  uint8_t relay_cmd = 0;
  uint8_t trip_flag = 0;
  uint8_t fan_state = 0;

  float vdc_v = -1.0f;
  float idc_a = -1.0f;
  float pdc_w = -1.0f;
  float vout_rms = -1.0f;
  float iout_rms = -1.0f;
  float pout_w = -1.0f;
  float pf = -1.0f;
  float temp_c = -1.0f;

  float ploss_w = 0.0f;
  float efficiency = 0.0f;
  float dtdt_c_per_min = 0.0f;

  float cascade_protect_score = -1.0f;
  float electrical_score = 0.0f;
  float loss_score = 0.0f;
  float thermal_score = 0.0f;
  float cascade_max_score = -1.0f;
  float cascade_weighted_score = -1.0f;
  float cascade_hybrid_score = -1.0f;
  uint8_t final_anfis_state = 0;
  float final_anfis_score = -1.0f;
  uint8_t anfis_valid = 0;
  uint8_t transient_flag = 0;

  String load_id = "UNKNOWN";
  uint8_t load_confidence = 0;

  uint8_t ac_ok = 0;
  uint8_t dc_ok = 0;
  uint8_t pzem_pair_ok = 0;

  uint8_t auto_retry_count = 0;
  String retry_state = "none";
  uint8_t latched_trip = 0;
};

extern CapTelemetry telem;

static inline bool telemIsStale(unsigned long staleMs = 5000UL) {
  return (!telem.valid) || ((millis() - telem.lastRxMs) > staleMs);
}

static inline const char* stateText(uint8_t st) {
  switch (st) {
    case 0: return "S0 정상";
    case 1: return "S1 경고";
    case 2: return "S2 고장 의심";
    case 3: return "S3 차단 후보/Trip";
    default: return "Unknown";
  }
}

static inline const char* stateIcon(uint8_t st) {
  switch (st) {
    case 0: return "✅";
    case 1: return "⚠️";
    case 2: return "🚨";
    case 3: return "⛔";
    default: return "❔";
  }
}

static inline String relayText() {
  return telem.relay_state ? "ON(부하 연결)" : "OFF(부하 차단)";
}
