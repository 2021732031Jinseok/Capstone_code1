#pragma once
#include <WiFiClientSecure.h>
#include <UniversalTelegramBot.h>
#include <ArduinoJson.h>
#include "Config.h"
#include "TelemetryData.h"

WiFiClientSecure secured_client;
UniversalTelegramBot bot(BOT_TOKEN, secured_client);

unsigned long lastTimeBotRan = 0;
unsigned long lastEventSentMs = 0;

static String formatBoolOk(uint8_t v) {
  return v ? "OK" : "FAIL";
}

static String formatStatusMessage() {
  String msg;
  bool stale = telemIsStale(TELEMETRY_STALE_MS);

  msg += "⚡ [현재 인버터 상태]\n";
  if (stale) {
    msg += "⚠️ STM32 수신 데이터가 오래되었습니다.\n";
  }

  msg += String(stateIcon(telem.final_state_num)) + " 상태: " + telem.state_label + " (" + stateText(telem.final_state_num) + ")\n";
  msg += "원인: " + telem.fault_type + "\n";
  msg += "Trip Reason: " + telem.trip_reason + "\n";
  msg += "릴레이: " + relayText() + "\n";
  msg += "Trip Flag: " + String(telem.trip_flag ? "YES" : "NO") + "\n";
  msg += "Latched: " + String(telem.latched_trip ? "YES" : "NO") + "\n";
  msg += "Retry: " + telem.retry_state + " / count=" + String(telem.auto_retry_count) + "\n\n";

  msg += "[계측값]\n";
  msg += "DC 입력: " + String(telem.vdc_v, 2) + " V / " + String(telem.idc_a, 3) + " A / " + String(telem.pdc_w, 1) + " W\n";
  msg += "AC 출력: " + String(telem.vout_rms, 1) + " V / " + String(telem.iout_rms, 3) + " A / " + String(telem.pout_w, 1) + " W\n";
  msg += "PF: " + String(telem.pf, 2) + "\n";
  msg += "온도: " + String(telem.temp_c, 2) + " °C\n";
  msg += "손실: " + String(telem.ploss_w, 1) + " W\n";
  msg += "효율: " + String(telem.efficiency * 100.0f, 1) + " %\n";
  msg += "dT/dt: " + String(telem.dtdt_c_per_min, 2) + " °C/min\n\n";

  msg += "[ANFIS / 진단]\n";
  msg += "Cascade Score: " + String(telem.cascade_protect_score, 3) + "\n";
  msg += "Electrical/Loss/Thermal: " + String(telem.electrical_score, 3) + " / " + String(telem.loss_score, 3) + " / " + String(telem.thermal_score, 3) + "\n";
  msg += "Final ANFIS: state " + String(telem.final_anfis_state) + ", score " + String(telem.final_anfis_score, 3) + "\n";
  msg += "Rule State: " + String(telem.rule_state_num) + "\n";
  msg += "부하: " + telem.load_id + " / 신뢰도 " + String(telem.load_confidence) + "%\n";
  msg += "Transient: " + String(telem.transient_flag) + "\n\n";

  msg += "[통신]\n";
  msg += "AC PZEM: " + formatBoolOk(telem.ac_ok) + "\n";
  msg += "DC PZEM: " + formatBoolOk(telem.dc_ok) + "\n";
  msg += "Pair: " + formatBoolOk(telem.pzem_pair_ok) + "\n";
  msg += "수신: " + String(telem.rxCount) + " packets\n";
  msg += "STM32 time: " + String(telem.time_s) + " s\n";

  return msg;
}

void initTelegram() {
  secured_client.setInsecure();
  Serial.println("Telegram bot ready");
}

void handleNewMessages(int numNewMessages) {
  for (int i = 0; i < numNewMessages; i++) {
    String chat_id = String(bot.messages[i].chat_id);
    String text = bot.messages[i].text;
    text.trim();

    Serial.println("Telegram message from: " + chat_id);
    Serial.println("Text: " + text);

    if (chat_id != CHAT_ID) {
      bot.sendMessage(chat_id, "권한이 없습니다.", "");
      continue;
    }

    if (text == "/start") {
      String welcome = "캡스톤 인버터 보호 모니터링 봇입니다.\n";
      welcome += "/status : 전체 상태 확인\n";
      welcome += "/brief : 핵심 상태만 확인\n";
      bot.sendMessage(chat_id, welcome, "");
    }
    else if (text == "/status") {
      bool sent = bot.sendMessage(chat_id, formatStatusMessage(), "");
      Serial.println(sent ? "Telegram status sent" : "Telegram send failed");
    }
    else if (text == "/brief") {
      String msg;
      msg += String(stateIcon(telem.final_state_num)) + " " + telem.state_label + "\n";
      msg += "원인: " + telem.fault_type + " / " + telem.trip_reason + "\n";
      msg += "Relay: " + relayText() + "\n";
      msg += "Vdc=" + String(telem.vdc_v, 2) + "V, Vout=" + String(telem.vout_rms, 1) + "V, Iout=" + String(telem.iout_rms, 3) + "A\n";
      msg += "Temp=" + String(telem.temp_c, 1) + "°C, Score=" + String(telem.cascade_protect_score, 2) + "\n";
      bot.sendMessage(chat_id, msg, "");
    }
    else {
      bot.sendMessage(chat_id, "사용 가능한 명령어: /start, /status, /brief", "");
    }
  }
}

void runTelegram() {
  if (WiFi.status() != WL_CONNECTED) return;

  if (millis() - lastTimeBotRan > TELEGRAM_POLL_INTERVAL_MS) {
    int numNewMessages = bot.getUpdates(bot.last_message_received + 1);
    while (numNewMessages) {
      handleNewMessages(numNewMessages);
      numNewMessages = bot.getUpdates(bot.last_message_received + 1);
    }
    lastTimeBotRan = millis();
  }
}

void checkAndSendTelemetryEvent() {
  if (WiFi.status() != WL_CONNECTED || !telem.valid) return;

  static bool initialized = false;

  static uint8_t prevState = 0;
  static uint8_t prevTripFlag = 0;
  static uint8_t prevRelayState = 0;
  static uint8_t prevLatchedTrip = 0;

  static String prevFault = "NORMAL";
  static String prevTripReason = "NORMAL";
  static String prevRetryState = "none";
  static String prevLoad = "UNKNOWN";

  if (!initialized) {
    initialized = true;

    prevState = telem.final_state_num;
    prevTripFlag = telem.trip_flag;
    prevRelayState = telem.relay_state;
    prevLatchedTrip = telem.latched_trip;

    prevFault = telem.fault_type;
    prevTripReason = telem.trip_reason;
    prevRetryState = telem.retry_state;
    prevLoad = telem.load_id;

    return;
  }

  bool important = false;
  bool forceSend = false;
  String title = "";

  // 1. 상태 전이는 S0/S1/S2/S3 모두 즉시 알림
  if (telem.final_state_num != prevState) {
    important = true;
    forceSend = true;

    if (telem.final_state_num == 0) {
      title = "정상 상태 복귀";
    } else if (telem.final_state_num == 1) {
      title = "S1 경고 상태 진입";
    } else if (telem.final_state_num == 2) {
      title = "S2 고장 의심 상태 진입";
    } else if (telem.final_state_num == 3) {
      title = "S3 TRIP 상태 진입";
    } else {
      title = "상태 전이";
    }
  }

  // 2. Trip Flag 변화는 즉시 알림
  if (telem.trip_flag != prevTripFlag) {
    important = true;
    forceSend = true;

    if (telem.trip_flag != 0) {
      title = "TRIP 발생";
    } else {
      title = "Trip Flag 해제";
    }
  }

  // 3. 릴레이 변화는 즉시 알림
  if (telem.relay_state != prevRelayState) {
    important = true;
    forceSend = true;

    if (telem.relay_state == 0) {
      title = "릴레이 차단";
    } else {
      title = "릴레이 복귀";
    }
  }

  // 4. Latched Trip 변화도 즉시 알림
  if (telem.latched_trip != prevLatchedTrip) {
    important = true;
    forceSend = true;

    if (telem.latched_trip != 0) {
      title = "Latched Trip 발생";
    } else {
      title = "Latched Trip 해제";
    }
  }

  // 5. Fault / Trip Reason 변화
  if (telem.fault_type != prevFault || telem.trip_reason != prevTripReason) {
    important = true;

    // 보호 원인이 바뀌는 건 상태 판단에 중요하므로 즉시 알림
    forceSend = true;

    if (title.length() == 0) {
      title = "보호 원인 변경";
    }
  }

  // 6. Retry 상태 변화
  if (telem.retry_state != prevRetryState) {
    important = true;
    forceSend = true;

    if (title.length() == 0) {
      title = "복귀 동작 상태 변경";
    }
  }

  // 7. 부하 상태 변화는 일반 알림
  if (telem.load_id != prevLoad) {
    important = true;

    if (title.length() == 0) {
      title = "부하 상태 변경";
    }
  }

  bool canSendByInterval =
      (lastEventSentMs == 0UL) ||
      (millis() - lastEventSentMs >= TELEGRAM_EVENT_MIN_INTERVAL_MS);

  bool shouldSend = important && (forceSend || canSendByInterval);

  if (shouldSend) {
    String msg;

    msg += String(stateIcon(telem.final_state_num)) + " [" + title + "]\n";
    msg += "상태: " + telem.state_label + " (" + stateText(telem.final_state_num) + ")\n";
    msg += "원인: " + telem.fault_type + " / " + telem.trip_reason + "\n";
    msg += "Relay: " + relayText() + "\n";
    msg += "Trip Flag: " + String(telem.trip_flag ? "YES" : "NO") + "\n";
    msg += "Latched: " + String(telem.latched_trip ? "YES" : "NO") + "\n";
    msg += "Retry: " + telem.retry_state + " / count=" + String(telem.auto_retry_count) + "\n\n";

    msg += "[계측]\n";
    msg += "Vdc=" + String(telem.vdc_v, 2) + "V, ";
    msg += "Vout=" + String(telem.vout_rms, 1) + "V, ";
    msg += "Iout=" + String(telem.iout_rms, 3) + "A\n";
    msg += "Pout=" + String(telem.pout_w, 1) + "W, ";
    msg += "Temp=" + String(telem.temp_c, 1) + "°C\n\n";

    msg += "[진단]\n";
    msg += "Cascade Score=" + String(telem.cascade_protect_score, 2) + "\n";
    msg += "Electrical/Loss/Thermal=";
    msg += String(telem.electrical_score, 2) + " / ";
    msg += String(telem.loss_score, 2) + " / ";
    msg += String(telem.thermal_score, 2) + "\n";
    msg += "Load=" + telem.load_id + " / Conf=" + String(telem.load_confidence) + "%\n\n";

    msg += "[통신]\n";
    msg += "AC=" + formatBoolOk(telem.ac_ok);
    msg += ", DC=" + formatBoolOk(telem.dc_ok);
    msg += ", Pair=" + formatBoolOk(telem.pzem_pair_ok) + "\n";
    msg += "RX packets=" + String(telem.rxCount);
    msg += ", STM32 time=" + String(telem.time_s) + "s\n";

    bool sent = bot.sendMessage(CHAT_ID, msg, "");

    Serial.println(sent ? "Telegram event sent: " + title
                        : "Telegram event send failed: " + title);

    if (sent) {
      lastEventSentMs = millis();

      // 전송 성공했을 때만 이전 상태 갱신
      prevState = telem.final_state_num;
      prevTripFlag = telem.trip_flag;
      prevRelayState = telem.relay_state;
      prevLatchedTrip = telem.latched_trip;

      prevFault = telem.fault_type;
      prevTripReason = telem.trip_reason;
      prevRetryState = telem.retry_state;
      prevLoad = telem.load_id;
    }

    return;
  }

  // 중요 이벤트인데 전송 제한 때문에 못 보낸 경우,
  // prev값을 업데이트하지 않는다.
  // 그래야 다음 루프에서 다시 알림 기회를 가진다.
  if (important) {
    Serial.println("Telegram event pending: " + title);
    return;
  }

  // 아무 이벤트도 없을 때만 현재값 유지
  prevState = telem.final_state_num;
  prevTripFlag = telem.trip_flag;
  prevRelayState = telem.relay_state;
  prevLatchedTrip = telem.latched_trip;

  prevFault = telem.fault_type;
  prevTripReason = telem.trip_reason;
  prevRetryState = telem.retry_state;
  prevLoad = telem.load_id;
}