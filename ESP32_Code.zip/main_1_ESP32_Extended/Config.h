#pragma once

// =========================================================
// WiFi 설정
// =========================================================
const char* ssid = "kojungkyun";
const char* password = "123456789";

// =========================================================
// Blynk 설정
// Blynk Console에서 발급받은 값으로 교체하세요.
// =========================================================
#define BLYNK_TEMPLATE_ID "TMPL6UNIcYAtR"
#define BLYNK_TEMPLATE_NAME "Smart IoT Energy Meter"
#define BLYNK_AUTH_TOKEN "8Wn_lDSu7g3PFpxMXYsw7ZCZObFalCLx"
#define BLYNK_PRINT Serial

// =========================================================
// Telegram 설정
// BotFather 토큰과 본인 chat id로 교체하세요.
// =========================================================
#define BOT_TOKEN "8264377892:AAGe9KVsnNfd61jljyTuIRZnFtfH2CX6v4U"
#define CHAT_ID "8522048951"

// =========================================================
// STM32 UART 설정
// STM32 V4.14의 USART2가 115200으로 설정되어 있으므로 반드시 일치시킵니다.
// =========================================================
#define STM32_RXD2 16   // ESP32 RX2  <- STM32 USART2_TX
#define STM32_TXD2 17   // ESP32 TX2  -> STM32 USART2_RX, 현재는 미사용 가능
#define STM32_BAUDRATE 115200

// =========================================================
// 주기 설정
// =========================================================
#define BLYNK_UPDATE_INTERVAL_MS       2000UL
#define TELEGRAM_POLL_INTERVAL_MS      1000UL
#define WIFI_RECONNECT_INTERVAL_MS     5000UL
#define TELEGRAM_EVENT_MIN_INTERVAL_MS 3000UL
#define TELEMETRY_STALE_MS             5000UL
