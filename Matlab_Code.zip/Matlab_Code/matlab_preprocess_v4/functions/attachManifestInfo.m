function T = attachManifestInfo(T, m)
% manifest에 있는 정보를 raw CSV에 부착하거나 덮어쓴다.
% raw의 run_id가 틀렸을 가능성을 줄이기 위해 manifest 기준을 우선한다.

n = height(T);
T.source_file = repmat(string(m.file_name), n, 1);
T.run_title = repmat(string(m.run_title), n, 1);
T.run_id = repmat(double(m.run_id), n, 1);
T.load_id = repmat(string(m.load_id), n, 1);
T.load_type = repmat(string(m.load_type), n, 1);
T.load_label_W = repmat(double(m.load_label_W), n, 1);
T.test_condition = repmat(string(m.test_condition), n, 1);
T.method = repmat(upper(string(m.method)), n, 1);
T.role_plan = repmat(lower(string(m.role)), n, 1);
T.planned_state = repmat(upper(string(m.planned_state)), n, 1);
T.planned_cause = repmat(upper(string(m.planned_cause)), n, 1);
T.manifest_note = repmat(string(m.note), n, 1);
end
