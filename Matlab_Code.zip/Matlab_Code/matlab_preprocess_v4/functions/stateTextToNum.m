function n = stateTextToNum(s)
s = upper(string(s));
if s == "S0" || s == "NORMAL" || s == "0"
    n = 0;
elseif s == "S1" || s == "WARNING" || s == "1"
    n = 1;
elseif s == "S2" || contains(s, "FAULT") || s == "2"
    n = 2;
elseif s == "S3" || s == "TRIP" || s == "3"
    n = 3;
else
    n = NaN;
end
end
