function T = applyMethodRules(T, m, evRows, cfg)
% segment_label.csv가 없을 때 method와 event_log를 기준으로 자동 전처리 규칙 적용

n = height(T);
method = upper(string(m.method));
role = lower(string(m.role));

T.phase_proc = repmat("steady", n, 1);
T.use_for_train = zeros(n,1);
T.use_for_test = zeros(n,1);
T.use_for_validation = zeros(n,1);
T.exclude_reason = repmat("", n, 1);

% 기본 role 설정
if role == "test"
    T.use_for_test(:) = 1;
elseif role == "validation" || role == "event"
    T.use_for_validation(:) = 1;
else
    T.use_for_train(:) = 1;
end

switch method
    case {"M1", "M2"}  % 정상, 정상 반복
        T = excludeInitial(T, getInitialExclude(m, cfg), "startup");

    case "M3"           % UV 고정
        T = processVdcChange(T, evRows, cfg, false);

    case "M4"           % UV Sweep
        T = processVdcChange(T, evRows, cfg, true);

    case "M5"           % VD_CHECK
        T = excludeInitial(T, getInitialExclude(m, cfg), "startup");
        T.phase_proc(T.use_for_train == 1 | T.use_for_test == 1 | T.use_for_validation == 1) = "steady";

    case "M6"           % OV/Stepoff event
        T = processLoadStep(T, evRows, cfg, true);
        T.use_for_train(:) = 0;
        T.use_for_validation(T.exclude_reason == "") = 1;
        T.phase_proc(T.use_for_validation == 1) = "event";

    case "M7"           % 부하스텝
        T = processLoadStep(T, evRows, cfg, false);
        % 부하스텝은 초기 학습보다 validation 권장
        T.use_for_train(:) = 0;
        T.use_for_validation(T.exclude_reason == "") = 1;

    case "M8"           % 온도상승
        T = excludeInitial(T, getInitialExclude(m, cfg), "startup");

    case "M9"           % startup / ON-OFF
        T.use_for_train(:) = 0;
        T.use_for_test(:) = 0;
        T.use_for_validation(:) = 1;
        T.phase_proc(:) = "startup_event";

    case "M10"          % 위험 조건 짧은 이벤트
        T.use_for_train(:) = 0;
        T.use_for_test(:) = 0;
        T.use_for_validation(:) = 1;
        T.phase_proc(:) = "event";

    otherwise
        warning("Unknown method %s. Default: initial 30s excluded.", method);
        T = excludeInitial(T, cfg.defaultInitialExclude_s, "startup");
end

% method별 planned state/cause 기본값 부착은 addAutomaticLabels에서 수행
end

function ex = getInitialExclude(m, cfg)
ex = double(m.exclude_initial_s);
if isnan(ex) || ex < 0
    ex = cfg.defaultInitialExclude_s;
end
end
