function evRows = findMatchingEvents(eventLog, fileName, runId)
if isempty(eventLog) || height(eventLog) == 0
    evRows = table();
    return;
end

names = string(eventLog.Properties.VariableNames);
if ~ismember("file_name", names) || ~ismember("run_id", names)
    evRows = table();
    return;
end

eventLog.file_name = string(eventLog.file_name);
idx = (eventLog.file_name == string(fileName)) | (eventLog.run_id == runId);
evRows = eventLog(idx,:);
end
