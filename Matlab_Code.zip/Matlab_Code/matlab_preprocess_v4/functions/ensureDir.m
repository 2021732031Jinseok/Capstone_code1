function ensureDir(pathStr)
if ~exist(pathStr, "dir")
    mkdir(pathStr);
end
end
