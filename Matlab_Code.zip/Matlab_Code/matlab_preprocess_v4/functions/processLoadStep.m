function T = processLoadStep(T, evRows, cfg, isEventOnly)
% 부하스텝 / 부하제거 직후 transition 구간 제외

T = excludeInitial(T, cfg.defaultInitialExclude_s, "startup");

if isempty(evRows)
    eventTimes = detectLoadStepTimes(T, cfg);
    transition_s = cfg.loadStepTransitionExclude_s * ones(size(eventTimes));
else
    evRows = normalizeEventRows(evRows, cfg.loadStepTransitionExclude_s);
    eventTimes = evRows.event_time_s;
    transition_s = evRows.transition_exclude_s;
end

for i = 1:numel(eventTimes)
    t0 = eventTimes(i);
    ex = transition_s(i);
    idxTrans = T.time_s >= t0 & T.time_s < (t0 + ex);
    T.use_for_train(idxTrans) = 0;
    T.use_for_test(idxTrans) = 0;
    T.use_for_validation(idxTrans) = 0;
    T.phase_proc(idxTrans) = "transition";
    T.exclude_reason(idxTrans) = "load_transition";
end

idxValid = T.exclude_reason == "" & T.time_s >= cfg.defaultInitialExclude_s;
if isEventOnly
    T.phase_proc(idxValid) = "event";
else
    T.phase_proc(idxValid) = "steady";
end
end
