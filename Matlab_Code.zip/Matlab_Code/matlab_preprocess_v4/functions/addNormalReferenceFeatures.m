function T = addNormalReferenceFeatures(T, cfg)
% 부하별 정상 steady 평균을 기준으로 상대 변화율을 추가한다.
% 정상 기준이 없는 부하는 NaN으로 남는다.

if isempty(T) || height(T) == 0
    return;
end

T.Vout_ref = NaN(height(T),1);
T.Iout_ref = NaN(height(T),1);
T.Pout_ref = NaN(height(T),1);
T.Pdc_ref = NaN(height(T),1);
T.Temp_ref = NaN(height(T),1);

T.Vout_ratio = NaN(height(T),1);
T.Iout_ratio = NaN(height(T),1);
T.Pout_ratio = NaN(height(T),1);
T.Pdc_ratio = NaN(height(T),1);
T.Temp_delta = NaN(height(T),1);

normalIdx = T.StateNum == 0 & lower(T.phase_proc) == "steady" & T.use_for_train == 1;
loads = unique(T.load_id);

for i = 1:numel(loads)
    loadId = loads(i);
    idxRef = normalIdx & T.load_id == loadId;
    if nnz(idxRef) < 5
        continue;
    end

    voutRef = mean(T.Vout_rms(idxRef), "omitnan");
    ioutRef = mean(T.Iout_rms(idxRef), "omitnan");
    poutRef = mean(T.Pout_W(idxRef), "omitnan");
    pdcRef = mean(T.Pdc_W(idxRef), "omitnan");
    tempRef = mean(T.T_heatsink_C(idxRef), "omitnan");

    idxLoad = T.load_id == loadId;
    T.Vout_ref(idxLoad) = voutRef;
    T.Iout_ref(idxLoad) = ioutRef;
    T.Pout_ref(idxLoad) = poutRef;
    T.Pdc_ref(idxLoad) = pdcRef;
    T.Temp_ref(idxLoad) = tempRef;

    T.Vout_ratio(idxLoad) = T.Vout_rms(idxLoad) ./ voutRef;
    if ioutRef > 0
        T.Iout_ratio(idxLoad) = T.Iout_rms(idxLoad) ./ ioutRef;
    end
    if poutRef > 0
        T.Pout_ratio(idxLoad) = T.Pout_W(idxLoad) ./ poutRef;
    end
    if pdcRef > 0
        T.Pdc_ratio(idxLoad) = T.Pdc_W(idxLoad) ./ pdcRef;
    end
    T.Temp_delta(idxLoad) = T.T_heatsink_C(idxLoad) - tempRef;
end
end
