function T = forceTripLabels(T, cfg)
% raw CSV에 기록된 실제 Trip 이벤트를 최우선으로 S3 라벨링한다.
% event_log.csv에 TRIP 이벤트가 빠져 있어도 phase/trip_flag/relay_state/trip_reason으로 감지한다.
%
% 감지 조건:
% 1) phase == "trip"
% 2) trip_flag == 1
% 3) relay_state == 0 이면서 trip_reason이 NORMAL/NONE/blank가 아님
% 4) event_log/segment 등으로 이미 StateNum==3인 경우
%
% 이 함수는 addAutomaticLabels 또는 applySegmentLabels 이후, finalizeUseFlags 이전에 호출하는 것이 좋다.

if nargin < 2 || ~isfield(cfg, "forceTripRowsToS3") || ~cfg.forceTripRowsToS3
    return;
end

n = height(T);
idxTrip = false(n,1);

vars = string(T.Properties.VariableNames);

% 1) phase == trip
if ismember("phase", vars)
    ph = lower(strtrim(string(T.phase)));
    idxTrip = idxTrip | ph == "trip" | contains(ph, "trip");
end

% 2) phase_proc == trip, if already marked
if ismember("phase_proc", vars)
    php = lower(strtrim(string(T.phase_proc)));
    idxTrip = idxTrip | php == "trip" | contains(php, "trip");
end

% 3) trip_flag == 1
if ismember("trip_flag", vars)
    tf = toNumericSafe(T.trip_flag);
    idxTrip = idxTrip | (tf == 1);
end

% 4) relay_state == 0 and trip_reason is meaningful
if ismember("relay_state", vars) && ismember("trip_reason", vars)
    rs = toNumericSafe(T.relay_state);
    tr = upper(strtrim(string(T.trip_reason)));
    hasReason = ~(tr == "" | tr == "NORMAL" | tr == "NONE" | tr == "0" | tr == "NAN" | tr == "NA");
    idxTrip = idxTrip | (rs == 0 & hasReason);
end

% 5) StateNum already 3 from segment_label
if ismember("StateNum", vars)
    st = toNumericSafe(T.StateNum);
    idxTrip = idxTrip | (st == 3);
end

% 실제 trip 직전 구간도 S3 후보로 확장한다.
% 이 구간은 릴레이가 이미 꺼진 후의 0V 데이터보다 ANFIS 학습에 더 의미가 있다.
if any(idxTrip) && ismember("time_s", vars) && isfield(cfg, "tripLeadWindow_s") && cfg.tripLeadWindow_s > 0
    tripTimes = T.time_s(idxTrip);
    tripTimes = tripTimes(~isnan(tripTimes));

    if ~isempty(tripTimes)
        tripTimes = sort(tripTimes(:));
        % 연속 trip 구간은 시작 시각만 사용
        tripStartTimes = tripTimes([true; diff(tripTimes) > max(1, cfg.sampleTime_s * 2)]);
        idxLead = false(n,1);

        for ii = 1:numel(tripStartTimes)
            t0 = tripStartTimes(ii);
            idxLead = idxLead | (T.time_s >= (t0 - cfg.tripLeadWindow_s) & T.time_s <= t0);
        end

        idxTrip = idxTrip | idxLead;
    end
end

if ~any(idxTrip)
    return;
end

% 필요한 출력 열이 없으면 생성
if ~ismember("StateNum", vars)
    T.StateNum = zeros(n,1);
end
if ~ismember("StateLabel", vars)
    T.StateLabel = repmat("S0", n, 1);
end
if ~ismember("CauseCode", vars)
    T.CauseCode = zeros(n,1);
end
if ~ismember("CauseLabel", vars)
    T.CauseLabel = repmat("NORMAL", n, 1);
end
if ~ismember("phase_proc", string(T.Properties.VariableNames))
    T.phase_proc = repmat("steady", n, 1);
end

% S3 강제 적용
T.StateNum(idxTrip) = 3;
T.StateLabel(idxTrip) = "S3";
T.phase_proc(idxTrip) = "trip";

% Cause는 trip_reason 우선, 없으면 planned_cause, 그래도 없으면 MIXED
causeLabel = repmat("MIXED", sum(idxTrip), 1);

if ismember("trip_reason", string(T.Properties.VariableNames))
    tr = upper(strtrim(string(T.trip_reason(idxTrip))));
    validReason = ~(tr == "" | tr == "NORMAL" | tr == "NONE" | tr == "0" | tr == "NAN" | tr == "NA");
    causeLabel(validReason) = tr(validReason);
end

if ismember("planned_cause", string(T.Properties.VariableNames))
    pc = upper(strtrim(string(T.planned_cause(idxTrip))));
    need = causeLabel == "MIXED" | causeLabel == "";
    validPlan = ~(pc == "" | pc == "NORMAL" | pc == "NONE" | pc == "0" | pc == "NAN" | pc == "NA");
    causeLabel(need & validPlan) = pc(need & validPlan);
end

idxTripList = find(idxTrip);
for j = 1:numel(idxTripList)
    k = idxTripList(j);
    ctext = causeLabel(j);

    ccode = causeTextToCode(ctext);
    if isnan(ccode)
        if contains(ctext, "TRIP")
            ccode = 9;
            ctext = "MIXED";
        else
            ccode = 9;
            ctext = "MIXED";
        end
    end

    T.CauseCode(k) = ccode;
    T.CauseLabel(k) = ctext;
end

% 실제 Trip 행이 train/test/validation 어디에도 못 들어가는 것을 방지한다.
if ismember("use_for_train", string(T.Properties.VariableNames)) && ...
   ismember("use_for_test", string(T.Properties.VariableNames)) && ...
   ismember("use_for_validation", string(T.Properties.VariableNames))

    % 먼저 모든 Trip 행을 보존 대상으로 만든다.
    if isfield(cfg, "forceTripRowsToTrain") && cfg.forceTripRowsToTrain
        T.use_for_train(idxTrip) = 1;
        T.use_for_test(idxTrip) = 0;
        T.use_for_validation(idxTrip) = 0;
    else
        % train에 넣지 않을 경우 validation으로 보존한다.
        T.use_for_train(idxTrip) = 0;
        T.use_for_test(idxTrip) = 0;
        T.use_for_validation(idxTrip) = 1;
    end
end

if ismember("exclude_reason", string(T.Properties.VariableNames))
    T.exclude_reason(idxTrip) = "";
end

end

function x = toNumericSafe(v)
if isnumeric(v)
    x = v;
else
    x = str2double(string(v));
end
end
