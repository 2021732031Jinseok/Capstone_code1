function master = appendTableSafe(master, T)
% appendTableSafe.m
% 서로 다른 raw CSV 헤더/열 개수로 인해 table vertcat이 실패하는 문제를 방지한다.
% - master와 T의 변수명을 union으로 맞춘다.
% - 한쪽에 없는 변수는 적절한 missing 값으로 추가한다.
% - 같은 이름인데 타입이 다르면 숫자끼리는 double, 그 외는 string으로 통일한다.

if isempty(master) || width(master) == 0
    master = T;
    return;
end

[master, T] = alignSchemas(master, T);
master = [master; T];
end

function [A, B] = alignSchemas(A, B)
varsA = string(A.Properties.VariableNames);
varsB = string(B.Properties.VariableNames);

% master의 기존 순서를 유지하고, 새로 발견된 변수는 뒤에 붙인다.
allVars = [varsA, setdiff(varsB, varsA, 'stable')];

for v = allVars
    inA = ismember(v, varsA);
    inB = ismember(v, varsB);

    if ~inA && inB
        Bcol = B.(v);
        A.(v) = makeMissingColumnLike(Bcol, height(A));
        varsA = string(A.Properties.VariableNames);
    elseif inA && ~inB
        Acol = A.(v);
        B.(v) = makeMissingColumnLike(Acol, height(B));
        varsB = string(B.Properties.VariableNames);
    end

    % 같은 이름인데 타입이 다른 경우 통일
    if ismember(v, string(A.Properties.VariableNames)) && ismember(v, string(B.Properties.VariableNames))
        a = A.(v);
        b = B.(v);
        if ~strcmp(class(a), class(b))
            if (isnumeric(a) || islogical(a)) && (isnumeric(b) || islogical(b))
                A.(v) = double(a);
                B.(v) = double(b);
            else
                A.(v) = string(a);
                B.(v) = string(b);
            end
        end
    end
end

% 최종 변수 순서 맞춤
A = A(:, cellstr(allVars));
B = B(:, cellstr(allVars));
end

function x = makeMissingColumnLike(ref, n)
% ref와 비슷한 타입/열수의 missing column 생성
if isempty(ref)
    x = strings(n,1);
    return;
end

sz = size(ref);
if numel(sz) < 2
    ncol = 1;
else
    ncol = sz(2);
end

if isnumeric(ref)
    x = NaN(n, ncol);
elseif islogical(ref)
    x = false(n, ncol);
elseif isstring(ref)
    x = strings(n, ncol);
elseif iscell(ref)
    x = repmat({''}, n, ncol);
elseif iscategorical(ref)
    x = categorical(strings(n, ncol));
elseif isdatetime(ref)
    x = NaT(n, ncol);
else
    % 알 수 없는 타입은 string으로 처리
    x = strings(n, ncol);
end
end
