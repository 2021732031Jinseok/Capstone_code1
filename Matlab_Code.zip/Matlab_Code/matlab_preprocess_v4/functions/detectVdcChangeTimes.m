function eventTimes = detectVdcChangeTimes(T, cfg)
dV = [0; abs(diff(T.Vdc_V))];
idx = find(dV > cfg.vdcChangeThreshold_V);
if isempty(idx)
    eventTimes = [];
    return;
end
rawTimes = T.time_s(idx);
eventTimes = collapseCloseEvents(rawTimes, cfg.minEventGap_s);
end
