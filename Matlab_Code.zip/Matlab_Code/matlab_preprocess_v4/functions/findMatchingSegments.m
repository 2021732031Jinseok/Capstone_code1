function segRows = findMatchingSegments(segmentLabel, fileName, runId)
if isempty(segmentLabel) || height(segmentLabel) == 0
    segRows = table();
    return;
end

names = string(segmentLabel.Properties.VariableNames);
if ~ismember("file_name", names) || ~ismember("run_id", names)
    segRows = table();
    return;
end

segmentLabel.file_name = string(segmentLabel.file_name);
idx = (segmentLabel.file_name == string(fileName)) | (segmentLabel.run_id == runId);
segRows = segmentLabel(idx,:);
end
