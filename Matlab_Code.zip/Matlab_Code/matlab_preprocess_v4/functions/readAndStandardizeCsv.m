function T = readAndStandardizeCsv(filePath, cfg)
% raw CSV를 읽고, 필요한 열이 없으면 기본 열을 추가한다.
% 숫자로 읽혀야 할 열은 숫자로 변환을 시도한다.
% MATLAB 버전별 ImportOptions 차이를 피하기 위해 WhitespaceRule 설정은 선택적으로만 적용한다.

try
    opts = detectImportOptions(filePath, "NumHeaderLines", 0);

    % 일부 MATLAB 버전/변수 타입에서는 WhitespaceRule, EmptyFieldRule이 지원되지 않는다.
    % 따라서 텍스트형 변수에만 시도하고, 실패하면 옵션 없이 계속 진행한다.
    try
        varTypes = string(opts.VariableTypes);
        varNames = string(opts.VariableNames);
        textVars = varNames(varTypes == "char" | varTypes == "string" | varTypes == "categorical");

        if ~isempty(textVars)
            try
                opts = setvaropts(opts, cellstr(textVars), "WhitespaceRule", "preserve");
            catch
                % 현재 MATLAB 버전에서 지원하지 않으면 무시
            end

            try
                opts = setvaropts(opts, cellstr(textVars), "EmptyFieldRule", "auto");
            catch
                % 현재 MATLAB 버전에서 지원하지 않으면 무시
            end
        end
    catch
        % opts.VariableTypes 접근이 불가능한 버전이면 옵션 설정 생략
    end

    try
        T = readtable(filePath, opts, "TextType", "string");
    catch
        T = readtable(filePath, opts);
    end
catch
    % detectImportOptions 자체가 실패할 경우 기본 readtable로 재시도
    try
        T = readtable(filePath, "TextType", "string");
    catch
        T = readtable(filePath);
    end
end

% 열 이름 정리
T.Properties.VariableNames = matlab.lang.makeValidName(T.Properties.VariableNames);

% 필수 열 기본값 추가
numericDefaults = struct( ...
    "time_s", NaN, "run_id", NaN, "load_label_W", NaN, ...
    "Vout_rms", NaN, "Iout_rms", NaN, "Pout_W", NaN, "PF", NaN, ...
    "Vdc_V", NaN, "Idc_A", NaN, "Pdc_W", NaN, ...
    "T_heatsink_C", NaN, "T_ambient_C", NaN, ...
    "relay_cmd", NaN, "relay_state", NaN, "trip_flag", NaN, "fan_state", NaN);

numFields = string(fieldnames(numericDefaults));
for f = numFields'
    if ~ismember(f, string(T.Properties.VariableNames))
        T.(f) = repmat(numericDefaults.(f), height(T), 1);
    else
        T.(f) = forceNumeric(T.(f));
    end
end

stringDefaults = ["load_id","load_type","test_condition","phase","Note", ...
                  "trip_reason","state_label","fault_type","trip_threshold_used"];
for f = stringDefaults
    if ~ismember(f, string(T.Properties.VariableNames))
        T.(f) = strings(height(T),1);
    else
        T.(f) = string(T.(f));
    end
end

% time_s가 없거나 NaN이면 행 번호 기반으로 생성
if all(isnan(T.time_s))
    T.time_s = (0:height(T)-1)' * cfg.sampleTime_s;
end

end

function x = forceNumeric(x)
if isnumeric(x)
    return;
end
x = str2double(string(x));
end
