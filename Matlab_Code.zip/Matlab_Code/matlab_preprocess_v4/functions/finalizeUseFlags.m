function T = finalizeUseFlags(T, cfg)
% 최종 학습/검증 사용 여부 정리

if ~ismember("exclude_reason", string(T.Properties.VariableNames))
    T.exclude_reason = repmat("", height(T), 1);
end

% invalid row는 모든 dataset에서 제외
idxInvalid = isnan(T.Vout_rms) | isnan(T.Pdc_W) | isnan(T.T_heatsink_C) | isnan(T.StateNum);
T.use_for_train(idxInvalid) = 0;
T.use_for_test(idxInvalid) = 0;
T.use_for_validation(idxInvalid) = 0;
T.exclude_reason(idxInvalid) = "invalid_or_unlabeled";

% transition/startup/pre는 초기 train/test에서 제외. validation은 method에 따라 이미 부여된 경우만 유지.
idxExcludedPhase = ismember(lower(T.phase_proc), ["pre","startup","transition","startup_event"]);
T.use_for_train(idxExcludedPhase) = 0;
T.use_for_test(idxExcludedPhase) = 0;
if any(idxExcludedPhase & T.exclude_reason == "")
    T.exclude_reason(idxExcludedPhase & T.exclude_reason == "") = "phase_excluded";
end

% role_plan이 test이면 train을 test로 전환
idxRoleTest = lower(T.role_plan) == "test" & T.use_for_train == 1;
T.use_for_train(idxRoleTest) = 0;
T.use_for_test(idxRoleTest) = 1;

% role_plan이 validation/event이면 train을 validation으로 전환
idxRoleVal = (lower(T.role_plan) == "validation" | lower(T.role_plan) == "event") & T.use_for_train == 1;
T.use_for_train(idxRoleVal) = 0;
T.use_for_validation(idxRoleVal) = 1;

% 1분 이하 event 계열은 train에서 제외
idxShortEvent = lower(T.role_plan) == "event" | ismember(upper(T.method), ["M9","M10"]);
T.use_for_train(idxShortEvent) = 0;
T.use_for_validation(idxShortEvent) = 1;


% 실제 Trip 행은 최종 단계에서 다시 한 번 보존한다.
% role_plan이 event/validation이어도 cfg.forceTripRowsToTrain=true이면 train으로 포함한다.
idxTripFinal = false(height(T),1);
if ismember("StateNum", string(T.Properties.VariableNames))
    idxTripFinal = idxTripFinal | (T.StateNum == 3);
end
if ismember("phase", string(T.Properties.VariableNames))
    idxTripFinal = idxTripFinal | contains(lower(string(T.phase)), "trip");
end
if ismember("trip_flag", string(T.Properties.VariableNames))
    idxTripFinal = idxTripFinal | (str2double(string(T.trip_flag)) == 1);
end

% invalid는 제외 유지, valid trip만 보존
idxTripFinal = idxTripFinal & ~idxInvalid;
if any(idxTripFinal)
    T.phase_proc(idxTripFinal) = "trip";
    T.StateNum(idxTripFinal) = 3;
    T.StateLabel(idxTripFinal) = "S3";
    if isfield(cfg, "forceTripRowsToTrain") && cfg.forceTripRowsToTrain
        T.use_for_train(idxTripFinal) = 1;
        T.use_for_test(idxTripFinal) = 0;
        T.use_for_validation(idxTripFinal) = 0;
    else
        T.use_for_train(idxTripFinal) = 0;
        T.use_for_test(idxTripFinal) = 0;
        T.use_for_validation(idxTripFinal) = 1;
    end
    T.exclude_reason(idxTripFinal) = "";
end

% 최종 어느 세트에도 안 들어가면 excluded reason 보강
idxNone = T.use_for_train == 0 & T.use_for_test == 0 & T.use_for_validation == 0;
T.exclude_reason(idxNone & T.exclude_reason == "") = "not_selected";
end
