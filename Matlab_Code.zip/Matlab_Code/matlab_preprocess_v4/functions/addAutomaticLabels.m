function T = addAutomaticLabels(T, cfg)
% 센서값 기준으로 StateNum, CauseCode를 자동 생성한다.
% segment_label.csv가 있으면 이 함수는 호출되지 않는다.

n = height(T);
T.StateNum = zeros(n,1);                 % 0=S0 Normal
T.StateLabel = repmat("S0", n, 1);
T.CauseCode = zeros(n,1);                % 0=NORMAL
T.CauseLabel = repmat("NORMAL", n, 1);

% 각 원인별 후보 상태 계산
uvState = zeros(n,1);
vdState = zeros(n,1);
otState = zeros(n,1);
lossState = zeros(n,1);

% UV: DC 입력 저전압
idx = T.Vdc_V < cfg.vdc_s0_min & T.Vdc_V >= cfg.vdc_s1_min;
uvState(idx) = 1;
idx = T.Vdc_V < cfg.vdc_s1_min & T.Vdc_V >= cfg.vdc_s2_min;
uvState(idx) = 2;
idx = T.Vdc_V < cfg.vdc_s2_min;
uvState(idx) = 3;

% VD: 출력전압 저하
idx = T.Vout_rms < cfg.vout_s0_min & T.Vout_rms >= cfg.vout_s1_min;
vdState(idx) = 1;
idx = T.Vout_rms < cfg.vout_s1_min & T.Vout_rms >= cfg.vout_s2_min;
vdState(idx) = 2;
idx = T.Vout_rms < cfg.vout_s2_min;
vdState(idx) = 3;

% OT: 온도
idx = T.T_heatsink_C >= cfg.temp_s1_min & T.T_heatsink_C < cfg.temp_s2_min;
otState(idx) = 1;
idx = T.T_heatsink_C >= cfg.temp_s2_min & T.T_heatsink_C < cfg.temp_s3_min;
otState(idx) = 2;
idx = T.T_heatsink_C >= cfg.temp_s3_min;
otState(idx) = 3;

% LOSS: 매우 낮은 효율 또는 과도한 손실은 2차 보조 라벨로 사용
% 초기 기준은 보수적으로 둔다. 필요 시 정상 부하별 평균 기준으로 조정.
idx = T.Efficiency < 0.75 & ~isnan(T.Efficiency);
lossState(idx) = max(lossState(idx), 1);
idx = T.Efficiency < 0.60 & ~isnan(T.Efficiency);
lossState(idx) = max(lossState(idx), 2);

% 최종 상태는 원인별 상태의 최대값
allStates = [uvState, vdState, otState, lossState];
[T.StateNum, maxIdx] = max(allStates, [], 2);

% CauseCode 결정: 같은 state가 여러 개면 MIXED
for k = 1:n
    if T.StateNum(k) == 0
        T.CauseCode(k) = 0;
        T.CauseLabel(k) = "NORMAL";
    else
        tied = find(allStates(k,:) == T.StateNum(k));
        if numel(tied) > 1
            T.CauseCode(k) = 9;
            T.CauseLabel(k) = "MIXED";
        else
            switch maxIdx(k)
                case 1
                    T.CauseCode(k) = 1; T.CauseLabel(k) = "UV";
                case 2
                    T.CauseCode(k) = 2; T.CauseLabel(k) = "VD";
                case 3
                    T.CauseCode(k) = 4; T.CauseLabel(k) = "OT";
                case 4
                    T.CauseCode(k) = 5; T.CauseLabel(k) = "LOSS";
            end
        end
    end
end

T.StateLabel(T.StateNum == 0) = "S0";
T.StateLabel(T.StateNum == 1) = "S1";
T.StateLabel(T.StateNum == 2) = "S2";
T.StateLabel(T.StateNum == 3) = "S3";

% method 또는 planned_cause가 STARTUP/LOAD_TRANSIENT면 Cause 보정
idxStartup = contains(upper(T.planned_cause), "STARTUP") | contains(upper(T.planned_cause), "LOAD_TRANSIENT");
T.CauseCode(idxStartup) = 8;
T.CauseLabel(idxStartup) = "LOAD_TRANSIENT";

end
