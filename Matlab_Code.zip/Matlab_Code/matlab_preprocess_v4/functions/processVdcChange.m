function T = processVdcChange(T, evRows, cfg, keepPreSegments)
% Vdc 변경 직후 transition 구간 제외
% evRows가 있으면 event_log 기준, 없으면 Vdc 변화량으로 자동 추정한다.

% 기본: 30초 전은 pre로 제외. UV_FIXED에서는 전압 변경 이후만 학습.
T = excludeInitial(T, 0, "pre");
T.use_for_train(:) = 1;
T.phase_proc(:) = "steady";
T.exclude_reason(:) = "";

if isempty(evRows)
    eventTimes = detectVdcChangeTimes(T, cfg);
    transition_s = cfg.vdcTransitionExclude_s * ones(size(eventTimes));
else
    evRows = normalizeEventRows(evRows, cfg.vdcTransitionExclude_s);
    eventTimes = evRows.event_time_s;
    transition_s = evRows.transition_exclude_s;
end

if isempty(eventTimes)
    % event가 없으면 일반적으로 초기 30초 제외
    T = excludeInitial(T, cfg.defaultInitialExclude_s, "startup");
    return;
end

% UV_FIXED에서는 첫 전압 변경 전 구간은 기준 확인용이므로 train 제외
if ~keepPreSegments
    firstEvent = min(eventTimes);
    idxPre = T.time_s < firstEvent;
    T.use_for_train(idxPre) = 0;
    T.phase_proc(idxPre) = "pre";
    T.exclude_reason(idxPre) = "pre_uv_reference";
end

for i = 1:numel(eventTimes)
    t0 = eventTimes(i);
    ex = transition_s(i);
    idxTrans = T.time_s >= t0 & T.time_s < (t0 + ex);
    T.use_for_train(idxTrans) = 0;
    T.use_for_test(idxTrans) = 0;
    T.use_for_validation(idxTrans) = 0;
    T.phase_proc(idxTrans) = "transition";
    T.exclude_reason(idxTrans) = "vdc_transition";
end

% Vdc 안정 구간 phase 후보
idxValid = T.exclude_reason == "";
T.phase_proc(idxValid & T.Vdc_V >= 22.8) = "steady";
T.phase_proc(idxValid & T.Vdc_V < 22.8 & T.Vdc_V >= 21.6) = "warning";
T.phase_proc(idxValid & T.Vdc_V < 21.6) = "fault_suspicious";
end
