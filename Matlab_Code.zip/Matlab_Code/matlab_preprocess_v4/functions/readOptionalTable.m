function T = readOptionalTable(filePath)
if isfile(filePath)
    T = readtable(filePath, "TextType", "string");
else
    T = table();
end
end
