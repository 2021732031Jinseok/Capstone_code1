function eventTimes = detectLoadStepTimes(T, cfg)
dP = [0; abs(diff(T.Pout_W))];
dI = [0; abs(diff(T.Iout_rms))];
idx = find((dP > cfg.poutStepThreshold_W) | (dI > cfg.ioutStepThreshold_A));
if isempty(idx)
    eventTimes = [];
    return;
end
rawTimes = T.time_s(idx);
eventTimes = collapseCloseEvents(rawTimes, cfg.minEventGap_s);
end
