function manifest = normalizeManifest(manifest)
required = ["file_name","run_id","run_title","load_id","load_type", ...
    "load_label_W","test_condition","method","role","planned_state", ...
    "planned_cause","exclude_initial_s","note"];

for v = required
    if ~ismember(v, string(manifest.Properties.VariableNames))
        if v == "run_id" || v == "load_label_W" || v == "exclude_initial_s"
            manifest.(v) = NaN(height(manifest),1);
        else
            manifest.(v) = strings(height(manifest),1);
        end
    end
end

manifest.file_name = string(manifest.file_name);
manifest.run_title = string(manifest.run_title);
manifest.load_id = string(manifest.load_id);
manifest.load_type = string(manifest.load_type);
manifest.test_condition = string(manifest.test_condition);
manifest.method = upper(string(manifest.method));
manifest.role = lower(string(manifest.role));
manifest.planned_state = upper(string(manifest.planned_state));
manifest.planned_cause = upper(string(manifest.planned_cause));
manifest.note = string(manifest.note);
end
