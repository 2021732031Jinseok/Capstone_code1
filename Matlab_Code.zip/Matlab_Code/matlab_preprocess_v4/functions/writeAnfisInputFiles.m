function writeAnfisInputFiles(trainSet, testSet, validationSet, cfg)
% ANFIS 학습용 숫자 행렬 CSV 생성: 마지막 열은 StateNum 출력
outDir = fullfile(cfg.processedDir, "anfis_inputs");
ensureDir(outDir);

writeOne(trainSet, cfg.anfisInputV1, cfg.outputVar, fullfile(outDir, "anfis_train_v1_input5.csv"));
writeOne(testSet, cfg.anfisInputV1, cfg.outputVar, fullfile(outDir, "anfis_test_v1_input5.csv"));
writeOne(validationSet, cfg.anfisInputV1, cfg.outputVar, fullfile(outDir, "anfis_validation_v1_input5.csv"));

writeOne(trainSet, cfg.anfisInputV2, cfg.outputVar, fullfile(outDir, "anfis_train_v2_input10.csv"));
writeOne(testSet, cfg.anfisInputV2, cfg.outputVar, fullfile(outDir, "anfis_test_v2_input10.csv"));
writeOne(validationSet, cfg.anfisInputV2, cfg.outputVar, fullfile(outDir, "anfis_validation_v2_input10.csv"));
end

function writeOne(T, inputVars, outputVar, outFile)
if isempty(T) || height(T) == 0
    writematrix([], outFile);
    return;
end

available = ismember(inputVars, string(T.Properties.VariableNames));
inputVars = inputVars(available);

needed = [inputVars, outputVar];
idxComplete = true(height(T),1);
for v = needed
    idxComplete = idxComplete & ~isnan(T.(v));
end

M = T{idxComplete, needed};
writematrix(M, outFile);
end
