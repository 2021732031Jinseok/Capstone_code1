function E = normalizeEventRows(E, defaultTransition_s)
required = ["file_name","run_id","event_time_s","event_type","event_value", ...
            "transition_exclude_s","state_after","cause_after","note"];
for v = required
    if ~ismember(v, string(E.Properties.VariableNames))
        if v == "event_time_s" || v == "transition_exclude_s" || v == "run_id"
            E.(v) = NaN(height(E),1);
        else
            E.(v) = strings(height(E),1);
        end
    end
end
E.event_type = upper(string(E.event_type));
E.event_value = string(E.event_value);
E.state_after = upper(string(E.state_after));
E.cause_after = upper(string(E.cause_after));
E.transition_exclude_s(isnan(E.transition_exclude_s) | E.transition_exclude_s <= 0) = defaultTransition_s;
end
