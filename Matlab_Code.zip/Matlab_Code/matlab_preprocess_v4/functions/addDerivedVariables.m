function T = addDerivedVariables(T, cfg)
% 파생변수 계산: Ploss, Efficiency, 30초 기준 dT/dt

T.Ploss_W = T.Pdc_W - T.Pout_W;
T.Efficiency = T.Pout_W ./ T.Pdc_W;

% 비정상 효율값 제거: 센서 오류 또는 무부하 특이값 가능
T.Efficiency(T.Efficiency < 0 | T.Efficiency > 1.5) = NaN;

% 30초 기준 dT/dt [C/min]
T.dTdt30_C_per_min = NaN(height(T),1);
windowN = max(1, round(cfg.dtdtWindow_s / cfg.sampleTime_s));

for k = (windowN+1):height(T)
    tNow = T.T_heatsink_C(k);
    tOld = T.T_heatsink_C(k-windowN);
    if ~isnan(tNow) && ~isnan(tOld)
        T.dTdt30_C_per_min(k) = (tNow - tOld) / (cfg.dtdtWindow_s / 60);
    end
end

% 하강률은 보호/열상승 특징으로는 0 처리한 버전도 제공
T.dTdt30_rise_C_per_min = T.dTdt30_C_per_min;
T.dTdt30_rise_C_per_min(T.dTdt30_rise_C_per_min < 0) = 0;

end
