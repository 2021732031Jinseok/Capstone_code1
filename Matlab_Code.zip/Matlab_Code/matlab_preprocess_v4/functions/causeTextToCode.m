function c = causeTextToCode(s)
s = upper(string(s));
if s == "NORMAL" || s == "S0" || s == "0"
    c = 0;
elseif contains(s, "UV")
    c = 1;
elseif contains(s, "VD") || contains(s, "ACVD")
    c = 2;
elseif contains(s, "OC")
    c = 3;
elseif contains(s, "OT") || contains(s, "TEMP")
    c = 4;
elseif contains(s, "LOSS") || contains(s, "EFF")
    c = 5;
elseif contains(s, "COMM")
    c = 6;
elseif contains(s, "SENSOR") || contains(s, "NTC")
    c = 7;
elseif contains(s, "STARTUP") || contains(s, "LOAD") || contains(s, "TRANSIENT")
    c = 8;
elseif contains(s, "MIXED")
    c = 9;
else
    c = NaN;
end
end
