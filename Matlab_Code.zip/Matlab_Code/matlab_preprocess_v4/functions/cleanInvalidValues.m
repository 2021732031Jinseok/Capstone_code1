function T = cleanInvalidValues(T, cfg)
% 센서 실패값을 NaN으로 변환한다.
% raw CSV는 수정하지 않고 processed table에서만 처리된다.

numericCols = ["Vout_rms","Iout_rms","Pout_W","PF","Vdc_V","Idc_A","Pdc_W", ...
               "T_heatsink_C","T_ambient_C"];

for c = numericCols
    if ismember(c, string(T.Properties.VariableNames))
        x = T.(c);
        x(x == cfg.invalidSensorValue) = NaN;
        T.(c) = x;
    end
end

% NTC invalid
if ismember("T_heatsink_C", string(T.Properties.VariableNames))
    T.T_heatsink_C(T.T_heatsink_C < cfg.invalidTempThreshold_C) = NaN;
end

% Pdc가 0 이하이면 효율 계산 불가
T.Pdc_W(T.Pdc_W <= 0) = NaN;
T.Pout_W(T.Pout_W < 0) = NaN;
T.Vout_rms(T.Vout_rms <= 0) = NaN;
T.Vdc_V(T.Vdc_V <= 0) = NaN;

end
