function cleanTimes = collapseCloseEvents(rawTimes, minGap_s)
if isempty(rawTimes)
    cleanTimes = [];
    return;
end
rawTimes = sort(rawTimes(:));
keep = [true; diff(rawTimes) > minGap_s];
cleanTimes = rawTimes(keep);
end
