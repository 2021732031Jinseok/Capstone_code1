function T = excludeInitial(T, exclude_s, phaseName)
idx = T.time_s < exclude_s;
T.use_for_train(idx) = 0;
T.use_for_test(idx) = 0;
T.use_for_validation(idx) = 0;
T.phase_proc(idx) = string(phaseName);
T.exclude_reason(idx) = "initial_excluded";
end
