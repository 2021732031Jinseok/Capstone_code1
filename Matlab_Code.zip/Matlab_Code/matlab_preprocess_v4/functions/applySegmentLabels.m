function T = applySegmentLabels(T, segRows, cfg)
% segment_label.csv가 있을 때 시간 구간별 phase/state/cause/use flag를 직접 적용한다.

n = height(T);
T.phase_proc = repmat("unlabeled", n, 1);
T.StateLabel = repmat("NA", n, 1);
T.StateNum = NaN(n,1);
T.CauseLabel = repmat("NA", n, 1);
T.CauseCode = NaN(n,1);
T.use_for_train = zeros(n,1);
T.use_for_test = zeros(n,1);
T.use_for_validation = zeros(n,1);
T.exclude_reason = repmat("segment_unlabeled", n, 1);

segRows = normalizeSegmentRows(segRows);

for i = 1:height(segRows)
    idx = T.time_s >= segRows.start_s(i) & T.time_s < segRows.end_s(i);

    T.phase_proc(idx) = segRows.phase(i);
    T.StateLabel(idx) = segRows.state(i);
    T.StateNum(idx) = stateTextToNum(segRows.state(i));
    T.CauseLabel(idx) = segRows.cause(i);
    T.CauseCode(idx) = causeTextToCode(segRows.cause(i));
    T.exclude_reason(idx) = "";

    if segRows.use_for_train(i) == 1
        role = lower(string(segRows.role(i)));
        if role == "test"
            T.use_for_test(idx) = 1;
        elseif role == "validation" || role == "event"
            T.use_for_validation(idx) = 1;
        else
            T.use_for_train(idx) = 1;
        end
    else
        T.exclude_reason(idx) = "segment_excluded";
    end
end

% invalid 제거
idxInvalid = isnan(T.Vout_rms) | isnan(T.Pdc_W) | isnan(T.T_heatsink_C);
T.use_for_train(idxInvalid) = 0;
T.use_for_test(idxInvalid) = 0;
T.use_for_validation(idxInvalid) = 0;
T.exclude_reason(idxInvalid) = "invalid_sensor_value";

end

function S = normalizeSegmentRows(S)
required = ["file_name","run_id","start_s","end_s","phase","state","cause","use_for_train","role","note"];
for v = required
    if ~ismember(v, string(S.Properties.VariableNames))
        if v == "start_s" || v == "end_s" || v == "use_for_train" || v == "run_id"
            S.(v) = NaN(height(S),1);
        else
            S.(v) = strings(height(S),1);
        end
    end
end
S.phase = lower(string(S.phase));
S.state = upper(string(S.state));
S.cause = upper(string(S.cause));
S.role = lower(string(S.role));
S.role(S.role == "") = "train";
end
