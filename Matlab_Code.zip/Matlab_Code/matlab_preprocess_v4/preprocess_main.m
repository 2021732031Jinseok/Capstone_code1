%% preprocess_main.m
% STM32 + PZEM + NTC CSV -> ANFIS 학습용 전처리 메인 스크립트
% 사용 순서:
% 1) raw/ 폴더에 Hercules 원본 CSV 저장
% 2) metadata/experiment_manifest.csv 작성 또는 template 파일명 변경
% 3) 필요 시 metadata/event_log.csv, metadata/segment_label.csv 작성
% 4) 이 스크립트 실행
%
% 원본 raw CSV는 수정하지 않고 processed/ 폴더에 새 파일을 생성한다.

clear; clc;

cfg = preprocess_config();
addpath(cfg.functionDir);

ensureDir(cfg.processedDir);
ensureDir(fullfile(cfg.processedDir, "diagnostics"));
ensureDir(fullfile(cfg.processedDir, "anfis_inputs"));

if ~isfile(cfg.manifestFile)
    error("experiment_manifest.csv가 없습니다. metadata/experiment_manifest_template.csv를 복사해서 experiment_manifest.csv로 저장한 뒤 작성하세요.");
end

manifest = readtable(cfg.manifestFile, "TextType", "string");
manifest = normalizeManifest(manifest);

eventLog = readOptionalTable(cfg.eventLogFile);
segmentLabel = readOptionalTable(cfg.segmentLabelFile);

masterAll = table();
masterUsed = table();
masterExcluded = table();

fprintf("[INFO] manifest rows: %d\n", height(manifest));

for i = 1:height(manifest)
    m = manifest(i,:);
    rawPath = fullfile(cfg.rawDir, m.file_name);

    if ~isfile(rawPath)
        warning("[SKIP] raw CSV 없음: %s", rawPath);
        continue;
    end

    fprintf("[LOAD] RUN %d : %s\n", m.run_id, m.file_name);

    T = readAndStandardizeCsv(rawPath, cfg);
    T = attachManifestInfo(T, m);
    T = cleanInvalidValues(T, cfg);
    T = addDerivedVariables(T, cfg);

    % segment_label.csv가 있으면 가장 우선 적용
    segRows = findMatchingSegments(segmentLabel, m.file_name, m.run_id);
    if ~isempty(segRows)
        T = applySegmentLabels(T, segRows, cfg);
    else
        evRows = findMatchingEvents(eventLog, m.file_name, m.run_id);
        T = applyMethodRules(T, m, evRows, cfg);
        T = addAutomaticLabels(T, cfg);
    end

    % raw CSV에 기록된 실제 Trip은 event_log 유무와 관계없이 최우선으로 S3 처리
    T = forceTripLabels(T, cfg);

    T = finalizeUseFlags(T, cfg);

    masterAll = appendTableSafe(masterAll, T);

    Tused = T(T.use_for_train == 1 | T.use_for_test == 1 | T.use_for_validation == 1, :);
    Texcluded = T(T.use_for_train == 0 & T.use_for_test == 0 & T.use_for_validation == 0, :);

    masterUsed = appendTableSafe(masterUsed, Tused);
    masterExcluded = appendTableSafe(masterExcluded, Texcluded);
end

% 정상 기준값 및 상대 변화율 추가
masterAll = addNormalReferenceFeatures(masterAll, cfg);
masterUsed = addNormalReferenceFeatures(masterUsed, cfg);
masterExcluded = addNormalReferenceFeatures(masterExcluded, cfg);

% dataset 분리
trainSet = masterUsed(masterUsed.use_for_train == 1, :);
testSet = masterUsed(masterUsed.use_for_test == 1, :);
validationSet = masterUsed(masterUsed.use_for_validation == 1, :);

% 저장
writetable(masterAll, fullfile(cfg.processedDir, "master_all_processed.csv"));
writetable(masterUsed, fullfile(cfg.processedDir, "master_used_processed.csv"));
writetable(masterExcluded, fullfile(cfg.processedDir, "diagnostics", "excluded_rows.csv"));
writetable(trainSet, fullfile(cfg.processedDir, "train_set.csv"));
writetable(testSet, fullfile(cfg.processedDir, "test_set.csv"));
writetable(validationSet, fullfile(cfg.processedDir, "validation_set.csv"));

% ANFIS용 숫자 입력 파일 생성
writeAnfisInputFiles(trainSet, testSet, validationSet, cfg);

% 요약 출력
fprintf("\n========== Preprocess Summary ==========" + newline);
fprintf("ALL rows        : %d\n", height(masterAll));
fprintf("USED rows       : %d\n", height(masterUsed));
fprintf("TRAIN rows      : %d\n", height(trainSet));
fprintf("TEST rows       : %d\n", height(testSet));
fprintf("VALIDATION rows : %d\n", height(validationSet));
fprintf("EXCLUDED rows   : %d\n", height(masterExcluded));

if height(trainSet) > 0
    disp("[TRAIN StateNum counts]");
    disp(groupcounts(trainSet, "StateNum"));
end

fprintf("\n[DONE] processed 폴더를 확인하세요.\n");
