%% train_anfis_v2_normalized_balanced.m
% ANFIS training script for inverter state diagnosis
% - Reads processed/train_set.csv and processed/test_set.csv
% - Filters invalid rows
% - Normalizes input variables using train-set mean/std
% - Optionally trains S0/S1/S2 only or S0/S1/S2/S3
% - Uses genfis instead of genfis2
% - Reports confusion matrix and accuracy
%
% 사용 위치:
%   matlab_preprocess_v4 폴더에서 실행
%   processed/train_set.csv, processed/test_set.csv가 있어야 함

clear; clc; close all;

%% ================= USER SETTINGS =================
% 1) 먼저 S0/S1/S2 모델로 검증하는 것을 권장
%    'S0S1S2' 또는 'S0S1S2S3'
modelMode = 'S0S1S2S3';

% 2) 1차 입력 변수. 처음에는 5개만 추천
inputVars = {'Vout_rms','Iout_rms','Pout_W','Vdc_V','T_heatsink_C'};

% 3) 데이터 균형 설정
balanceTrain = true;
% 각 클래스 최대 샘플 수. S0가 너무 많을 때 downsample됨.
maxPerClass = 2500;
% S3가 부족할 때 반복 복제할지 여부. 실제 데이터가 적으므로 기본 false 권장.
upsampleMinorClass = false;

% 4) ANFIS 설정
numEpochs = 60;
clusterRadius = 0.55;   % 0.45~0.70 사이에서 조정. 작을수록 rule 증가.

% 5) 출력 폴더
outDir = fullfile('processed','anfis_models');
if ~exist(outDir,'dir'); mkdir(outDir); end

%% ================= LOAD DATA =================
trainPath = fullfile('processed','train_set.csv');
testPath  = fullfile('processed','test_set.csv');

if ~isfile(trainPath)
    error('train_set.csv를 찾을 수 없습니다: %s', trainPath);
end
if ~isfile(testPath)
    error('test_set.csv를 찾을 수 없습니다: %s', testPath);
end

Ttr = readtable(trainPath);
Tte = readtable(testPath);

% 변수 존재 확인
needVars = [inputVars, {'StateNum'}];
for i = 1:numel(needVars)
    if ~ismember(needVars{i}, Ttr.Properties.VariableNames)
        error('train_set.csv에 필요한 열이 없습니다: %s', needVars{i});
    end
    if ~ismember(needVars{i}, Tte.Properties.VariableNames)
        error('test_set.csv에 필요한 열이 없습니다: %s', needVars{i});
    end
end

%% ================= FILTER ROWS =================
Ttr = keepValidRows(Ttr, inputVars, modelMode);
Tte = keepValidRows(Tte, inputVars, modelMode);

fprintf('\n[Before balance]\n');
showStateCounts(Ttr, 'Train');
showStateCounts(Tte, 'Test');

if balanceTrain
    Ttr = balanceByState(Ttr, maxPerClass, upsampleMinorClass);
end

fprintf('\n[After balance]\n');
showStateCounts(Ttr, 'Train');

Xtr = Ttr{:, inputVars};
Ytr = double(Ttr.StateNum);
Xte = Tte{:, inputVars};
Yte = double(Tte.StateNum);

%% ================= NORMALIZE INPUTS =================
mu = mean(Xtr, 1, 'omitnan');
sigma = std(Xtr, 0, 1, 'omitnan');
sigma(sigma == 0 | isnan(sigma)) = 1;

XtrN = (Xtr - mu) ./ sigma;
XteN = (Xte - mu) ./ sigma;

trainData = [XtrN Ytr];
testData  = [XteN Yte];

% 최종 NaN/Inf 방지
trainData = trainData(all(isfinite(trainData),2), :);
testData  = testData(all(isfinite(testData),2), :);

fprintf('\nTraining rows: %d\n', size(trainData,1));
fprintf('Checking rows: %d\n', size(testData,1));

%% ================= GENERATE INITIAL FIS =================
% genfis2 대신 genfis 사용
% MathWorks 권장: genfisOptions('SubtractiveClustering') + genfis
try
    opt = genfisOptions('SubtractiveClustering');
    opt.ClusterInfluenceRange = clusterRadius;
    fis0 = genfis(trainData(:,1:end-1), trainData(:,end), opt);
catch ME
    warning('genfis 옵션 방식 실패. 기본 genfis로 재시도합니다. 원인: %s', ME.message);
    fis0 = genfis(trainData(:,1:end-1), trainData(:,end));
end

fprintf('\nInitial FIS generated.\n');
try
    fprintf('Number of rules: %d\n', numel(fis0.Rules));
catch
    try
        fprintf('Number of rules: %d\n', length(fis0.rule));
    catch
    end
end

%% ================= TRAIN ANFIS =================
try
    optA = anfisOptions('InitialFIS', fis0, ...
        'EpochNumber', numEpochs, ...
        'DisplayANFISInformation', 1, ...
        'DisplayErrorValues', 1, ...
        'DisplayStepSize', 0, ...
        'DisplayFinalResults', 1, ...
        'ValidationData', testData);
    [fisTrained, trainError, stepSize, chkFis, chkError] = anfis(trainData, optA); %#ok<ASGLU>
    fisBest = chkFis;
catch ME
    warning('anfisOptions 방식 실패. 구버전 anfis 문법으로 재시도합니다. 원인: %s', ME.message);
    trainOpt = [numEpochs 0 0.01 0.9 1.1];
    dispOpt = [1 1 0 1];
    [fisTrained, trainError, stepSize, chkFis, chkError] = anfis(trainData, fis0, trainOpt, dispOpt, testData); %#ok<ASGLU>
    fisBest = chkFis;
end

%% ================= EVALUATE =================
YtrPred = evalfisCompat(fisBest, trainData(:,1:end-1));
YtePred = evalfisCompat(fisBest, testData(:,1:end-1));

YtrRound = clampRound(YtrPred, modelMode);
YteRound = clampRound(YtePred, modelMode);

YtrTrue = trainData(:,end);
YteTrue = testData(:,end);

trainAcc = mean(YtrRound == YtrTrue) * 100;
testAcc  = mean(YteRound == YteTrue) * 100;

fprintf('\n========== Evaluation ==========' );
fprintf('\nTrain rounded accuracy: %.2f %%\n', trainAcc);
fprintf('Test rounded accuracy : %.2f %%\n', testAcc);
fprintf('Train RMSE raw output : %.4f\n', sqrt(mean((YtrPred - YtrTrue).^2)));
fprintf('Test RMSE raw output  : %.4f\n', sqrt(mean((YtePred - YteTrue).^2)));

fprintf('\n[Train confusion matrix]\n');
dispConfusion(YtrTrue, YtrRound, modelMode);

fprintf('\n[Test confusion matrix]\n');
dispConfusion(YteTrue, YteRound, modelMode);

%% ================= SAVE =================
modelFile = fullfile(outDir, sprintf('anfis_%s_input%d_normalized.mat', modelMode, numel(inputVars)));
save(modelFile, 'fisBest', 'fisTrained', 'mu', 'sigma', 'inputVars', 'modelMode', ...
    'trainAcc', 'testAcc', 'trainError', 'chkError');
fprintf('\nSaved model: %s\n', modelFile);

% 예측 결과 저장
PredTest = table(YteTrue, YtePred, YteRound, 'VariableNames', {'TrueState','PredRaw','PredRound'});
writetable(PredTest, fullfile(outDir, sprintf('prediction_test_%s.csv', modelMode)));

%% ================= LOCAL FUNCTIONS =================
function T = keepValidRows(T, inputVars, modelMode)
    % State 범위
    if strcmpi(modelMode, 'S0S1S2')
        idx = T.StateNum >= 0 & T.StateNum <= 2;
    else
        idx = T.StateNum >= 0 & T.StateNum <= 3;
    end

    % 입력 NaN/Inf 제거
    X = T{:, inputVars};
    idx = idx & all(isfinite(X), 2);

    % 물리적으로 말이 안 되는 값 제거
    if ismember('Vout_rms', T.Properties.VariableNames)
        idx = idx & T.Vout_rms >= 0 & T.Vout_rms < 300;
    end
    if ismember('Iout_rms', T.Properties.VariableNames)
        idx = idx & T.Iout_rms >= 0 & T.Iout_rms < 30;
    end
    if ismember('Pout_W', T.Properties.VariableNames)
        idx = idx & T.Pout_W >= 0 & T.Pout_W < 2000;
    end
    if ismember('Vdc_V', T.Properties.VariableNames)
        idx = idx & T.Vdc_V > 0 & T.Vdc_V < 40;
    end
    if ismember('T_heatsink_C', T.Properties.VariableNames)
        idx = idx & T.T_heatsink_C > -50 & T.T_heatsink_C < 120;
    end

    T = T(idx,:);
end

function Tbal = balanceByState(T, maxPerClass, upsampleMinorClass)
    states = unique(T.StateNum);
    Tbal = table();
    rng(1);

    for i = 1:numel(states)
        s = states(i);
        Ts = T(T.StateNum == s, :);
        n = height(Ts);
        if n == 0
            continue;
        end

        if n > maxPerClass
            idx = randperm(n, maxPerClass);
            Ts = Ts(idx,:);
        elseif upsampleMinorClass && n < maxPerClass
            idx = randi(n, maxPerClass, 1);
            Ts = Ts(idx,:);
        end
        Tbal = [Tbal; Ts]; %#ok<AGROW>
    end
    Tbal = Tbal(randperm(height(Tbal)), :);
end

function y = evalfisCompat(fis, X)
    try
        y = evalfis(fis, X);
    catch
        y = evalfis(X, fis);
    end
    y = double(y(:));
end

function yr = clampRound(y, modelMode)
    yr = round(y);
    if strcmpi(modelMode, 'S0S1S2')
        yr(yr < 0) = 0; yr(yr > 2) = 2;
    else
        yr(yr < 0) = 0; yr(yr > 3) = 3;
    end
end

function showStateCounts(T, name)
    fprintf('\n%s State counts:\n', name);
    if isempty(T)
        disp('empty'); return;
    end
    states = unique(T.StateNum);
    for i = 1:numel(states)
        fprintf('  S%d: %d\n', states(i), sum(T.StateNum == states(i)));
    end
end

function dispConfusion(yTrue, yPred, modelMode)
    % Toolbox-free confusion matrix.
    % confusionmat() requires Statistics and Machine Learning Toolbox,
    % so this function computes the matrix manually.
    if strcmpi(modelMode, 'S0S1S2')
        cats = 0:2;
    else
        cats = 0:3;
    end

    C = zeros(numel(cats), numel(cats));

    yTrue = double(yTrue(:));
    yPred = double(yPred(:));

    for i = 1:numel(cats)
        for j = 1:numel(cats)
            C(i,j) = sum((yTrue == cats(i)) & (yPred == cats(j)));
        end
    end

    % Print matrix without array2table/compose dependency issues.
    fprintf('          ');
    for j = 1:numel(cats)
        fprintf('Pred_S%d    ', cats(j));
    end
    fprintf('\n');

    for i = 1:numel(cats)
        fprintf('True_S%d   ', cats(i));
        for j = 1:numel(cats)
            fprintf('%7d   ', C(i,j));
        end
        fprintf('\n');
    end

    rowSum = sum(C, 2);
    recall = zeros(numel(cats),1);
    for i = 1:numel(cats)
        if rowSum(i) > 0
            recall(i) = C(i,i) / rowSum(i) * 100.0;
        else
            recall(i) = NaN;
        end
    end

    fprintf('Recall:  ');
    for i = 1:numel(cats)
        if isnan(recall(i))
            fprintf('S%d=NaN%%   ', cats(i));
        else
            fprintf('S%d=%.2f%%   ', cats(i), recall(i));
        end
    end
    fprintf('\n');
end
