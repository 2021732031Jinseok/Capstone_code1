function cfg = preprocess_config()
% 전처리 공통 설정

rootDir = fileparts(mfilename("fullpath"));

cfg.rootDir = string(rootDir);
cfg.rawDir = fullfile(rootDir, "raw");
cfg.metadataDir = fullfile(rootDir, "metadata");
cfg.processedDir = fullfile(rootDir, "processed");
cfg.functionDir = fullfile(rootDir, "functions");

cfg.manifestFile = fullfile(cfg.metadataDir, "experiment_manifest.csv");
cfg.eventLogFile = fullfile(cfg.metadataDir, "event_log.csv");
cfg.segmentLabelFile = fullfile(cfg.metadataDir, "segment_label.csv");

% 샘플링 주기: 현재 CSV가 1초 1줄이라는 전제
cfg.sampleTime_s = 1;
cfg.dtdtWindow_s = 30;

% transition 제외 기본값
cfg.defaultInitialExclude_s = 30;
cfg.vdcTransitionExclude_s = 20;
cfg.loadStepTransitionExclude_s = 15;
cfg.onoffTransitionExclude_s = 20;

% invalid 처리 기준
cfg.invalidTempThreshold_C = -50;
cfg.invalidSensorValue = -1;

% 이벤트 자동 감지 임계값
cfg.vdcChangeThreshold_V = 0.30;
cfg.poutStepThreshold_W = 30;
cfg.ioutStepThreshold_A = 0.20;
cfg.minEventGap_s = 10;

% State 라벨 기준값: 필요 시 실험 결과에 맞게 수정
cfg.vdc_s0_min = 22.8;
cfg.vdc_s1_min = 21.6;
cfg.vdc_s2_min = 20.4;

cfg.vout_s0_min = 209;
cfg.vout_s1_min = 198;
cfg.vout_s2_min = 187;

cfg.temp_s1_min = 55;
cfg.temp_s2_min = 65;
cfg.temp_s3_min = 75;

% ANFIS 입력 변수
cfg.anfisInputV1 = ["Vout_rms", "Iout_rms", "Pout_W", "Vdc_V", "T_heatsink_C"];
cfg.anfisInputV2 = ["Vout_rms", "Iout_rms", "Pout_W", "PF", "Vdc_V", ...
                    "Pdc_W", "Ploss_W", "Efficiency", "T_heatsink_C", "dTdt30_C_per_min"];

% 출력 변수
cfg.outputVar = "StateNum";

% Trip/S3 라벨 처리 옵션
% raw CSV 안의 phase=trip, trip_flag=1, relay_state=0 + trip_reason 조건은
% event_log.csv 여부와 관계없이 S3로 강제 라벨링한다.
cfg.forceTripRowsToS3 = true;

% true이면 실제 trip 행을 train set에도 포함한다.
% S3 행이 너무 적게 나오는 경우 true 권장.
% 단, train_set에 S3가 늘어나는 것이 싫으면 false로 바꾸면 validation으로 남긴다.
cfg.forceTripRowsToTrain = true;

% 실제 trip 순간만 쓰면 행 수가 너무 적을 수 있으므로,
% trip 발생 직전 N초 구간도 S3 후보로 포함한다.
% 순수 phase=trip만 쓰고 싶으면 0으로 변경.
cfg.tripLeadWindow_s = 5;

% CauseCode 정의
% 0 NORMAL, 1 UV, 2 VD, 3 OC, 4 OT, 5 LOSS, 6 COMM, 7 SENSOR, 8 LOAD_TRANSIENT, 9 MIXED
end
